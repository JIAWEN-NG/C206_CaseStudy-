/**
 * 
 */
/**
 * I declare that this code was written by me.
 * I will not copy or allow others to copy my code.
 * I understand that copying code is considered as plagiarism.
 *
 * 20012122, 1 Aug 2021 20:24:03
 */

/**
 * @author 20012122
 *
 */
public class Buyer extends Account {

	public Buyer(String name, String role, String email, int password) {
		super(name, role, email, password);
	}
	public String toString(){
		String output = super.toString();
		return output;
	}

}
